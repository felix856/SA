package com.example.sa;

public class Eng {
    int pont_CienciasAgrarias, pont_CienciasBiologicas, pont_CienciasSaúde, pont_CienciasExatasTerra, pont_Engenharias, pont_CiênciasHumanas, pont_CiênciasSociaisAplicadas, pont_Linguística;


    public Eng(int pont_CienciasAgrarias, int pont_CienciasBiologicas, int pont_CienciasSaúde, int pont_CienciasExatasTerra, int pont_Engenharias, int pont_CiênciasHumanas, int pont_CiênciasSociaisAplicadas, int pont_Linguística) {
        this.pont_CienciasAgrarias = pont_CienciasAgrarias;
        this.pont_CienciasBiologicas = pont_CienciasBiologicas;
        this.pont_CienciasExatasTerra = pont_CienciasSaúde;
        this.pont_CienciasSaúde = pont_CienciasExatasTerra;
        this.pont_CiênciasHumanas = pont_CiênciasHumanas;
        this.pont_CiênciasSociaisAplicadas = pont_CiênciasSociaisAplicadas;
        this.pont_Engenharias = pont_Engenharias;
        this.pont_Linguística = pont_Linguística;
    }

}

