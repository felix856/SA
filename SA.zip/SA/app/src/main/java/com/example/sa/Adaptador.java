//package com.example.sa;
//
//
//
//import android.content.Context;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.TextView;
//
//import androidx.annotation.BinderThread;
//import androidx.annotation.NonNull;
//import androidx.recyclerview.widget.RecyclerView;
//
//import java.util.ArrayList;
//
//public class Adaptador extends RecyclerView.Adapter<Adaptador.MyViewHolder> {
//    Context context;
//    ArrayList<Integer> list;
//    Adaptador.OnItemClickListener listener;
//
//
//    public Adaptador(Context context, ArrayList<Integer> list, OnItemClickListener listener) {
//        this.context = context;
//        this.list = list;
//        this.listener = listener;
//    }
//
//    @NonNull
//    @Override
//    public Adaptador.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View f = LayoutInflater.from(context).inflate(R.layout.layout,parent,false);
//        return new Adaptador.MyViewHolder(f);
//
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull Adaptador.MyViewHolder holder, int position) {
//        area area  = list.get(position);
//        holder.nomearea.setText(area.getNome());
//        holder.ingredientes.setText(area.getIngredientes());
//        holder.preco.setText(Float.toString(area.getPreco()));
//        holder.itemView.setOnClickListener(view -> {
//            listener.onItemClick(Integer);
//        });
//    }
//
//    @Override
//    public int getItemCount() {
//        return list.size();
//    }
//
//    public interface OnItemClickListener {
//        void onItemClick(Area area);
//    }
//
//    public class MyViewHolder extends RecyclerView.ViewHolder {
//        TextView nomearea,ingredientes, preco;
//        public MyViewHolder(@NonNull View itemView) {
//            super(itemView);
//            nomearea = itemView.findViewById(R.id.cardnome);
//            ingredientes = itemView.findViewById(R.id.cardingredientes);
//            preco = itemView.findViewById(R.id.cardpreco);
//        }
//    }
//}
//
